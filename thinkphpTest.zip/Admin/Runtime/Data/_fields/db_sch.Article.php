<?php
return array ( 0 => 'id', 1 => 'author', 2 => 'subject', 3 => 'createtime', 4 => 'lastmodifytime', 5 => 'message', '_autoinc' => true, '_pk' => 'id', ); ?>