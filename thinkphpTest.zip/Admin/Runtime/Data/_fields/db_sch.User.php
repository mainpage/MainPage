<?php
return array ( 0 => 'id', 1 => 'username', 2 => 'password', 3 => 'createtime', 4 => 'ip', '_autoinc' => true, '_pk' => 'id', ); ?>