<?php
return array(
	//'配置项'=>'配置值'
	'URL_MODEL'	=>2,//rewrite 模式

	'DB_TYPE'			=>	'mysql',
	'DB_HOST'			=>	'localhost',
	'DB_NAME'			=>	'db_sch',
	'DB_USER'			=>	'root',			
	'DB_PWD'			=>	'1123',
	'DB_PORT'			=>	'3306',
	'DB_PREFIX'		    =>	'think_',
	//'SHOW_PAGE_TRACE'   =>   true, // 显示页面Trace信息
);
?>