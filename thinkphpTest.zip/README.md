MainPage
========

Personal web page & CMS
-----------------------

### Site Reception：<br>
> display personal blogs and other content

> based on bootstrap

### Backstage：
> a content management system

> based on thinkphp framwork

### Deployed in SAE platform of Sina.com
> site address: http://schspace.sinaapp.com
