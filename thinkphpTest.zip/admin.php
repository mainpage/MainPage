<?php
	define('THINK_PATH','./ThinkPHP/');
	define('APP_PATH','./Admin/');
	define('APP_NAME','Admin');
	define('APP_DEBUG',true);
	
	require	THINK_PATH.'Extend/Engine/Sae.php';
?>