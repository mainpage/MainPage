<?php
	define('APP_NAME', 'Home');
	define('APP_PATH', './Home/');     
    define('THINK_PATH','./ThinkPHP/');  //定义框架路径
    define('APP_DEBUG',TRUE); // 开启调试模式
    define('__PUBLIC__','__ROOT__/Public/');

    require THINK_PATH.'Extend/Engine/Sae.php';
?>